import test from 'node:test';
import assert from 'node:assert/strict';
import {planNative} from '../extension/native-planner.js';
import {installLegacyReader} from '../extension/native-reader.js';
import {legacyProfile} from '../extension/legacy-profile.js';
const scene=()=>({running:true,speed:110,player:{x:0,y:.8,z:0},groundY:.8,gravity:200,jumpHeight:20,body:{hx:3,hy:5,hz:3,y:6.3},lane:1,coins:[],obstacles:[]});
const coin=(x,z)=>({id:z,x,y:6,z,hx:4.5,hy:4.5,hz:4.5});
const train=(x,z,hz)=>({id:x,x,y:15.2,z,hx:8.5,hy:14,hz,tag:'HitTrain'});
test('clear road holds lateral position',()=>{const d=planNative(scene());assert.equal(d.targetX,0);assert.equal(d.risk,0);});
test('uses narrow safe corridor between coin and train colliders',()=>{const s=scene();s.coins=[coin(0,90),coin(0,120)];s.obstacles=[train(-20,90,90),train(20,90,90)];const d=planNative(s);assert.equal(Math.abs(d.targetX),8);assert.equal(d.risk,0);});
test('blocked corridor chooses the clear side',()=>{const s=scene();s.coins=[coin(0,80)];s.obstacles=[{x:-8,y:6,z:80,hx:8,hy:6,hz:20}];assert.ok(planNative(s).targetX>0);});
test('paused scene never requests movement',()=>{const s=scene();s.running=false;s.coins=[coin(0,20)];assert.equal(planNative(s).action,'hold');assert.equal(planNative(s).targetX,0);});
test('planner outputs bounded lateral positions',()=>{const s=scene();s.player.x=18;s.coins=[coin(20,80)];const d=planNative(s);assert.ok(d.targetX>=-20&&d.targetX<=20);});
test('ordinary controller commits to a clear adjacent lane before a coin row',()=>{const s=scene();s.coins=[coin(0,80),coin(0,100)];const d=planNative(s,{precision:false});assert.ok(['left','right'].includes(d.action),JSON.stringify(d));assert.equal(Math.abs(d.targetX),20);assert.equal(d.risk,0);});
test('ordinary controller chooses the executable clear side',()=>{const s=scene();s.coins=[coin(0,80)];s.obstacles=[train(-20,90,70)];const d=planNative(s,{precision:false});assert.equal(d.action,'right');assert.equal(d.targetX,20);assert.equal(d.risk,0);});
test('ordinary jump does not secretly change lanes in the simulation',()=>{const s=scene();s.obstacles=[{x:0,y:3,z:35,hx:40,hy:3,hz:2,tag:'HitBarrierJump'}];const d=planNative(s,{precision:false});assert.equal(d.action,'jump');assert.equal(d.targetX,0);assert.equal(d.risk,0);});
test('ordinary roll lowers the collider center to fit under a barrier',()=>{const s=scene();s.obstacles=[{x:0,y:20,z:30,hx:40,hy:13,hz:2,tag:'HitBarrierRoll'}];const d=planNative(s,{precision:false});assert.equal(d.action,'roll');assert.equal(d.targetX,0);assert.equal(d.risk,0);});
test('ordinary commands respect an unfinished lane change and recent command cooldown',()=>{const s=scene();s.coins=[coin(0,80)];s.changing=true;assert.ok(!['left','right'].includes(planNative(s,{precision:false}).action));assert.equal(planNative(s,{precision:false,commandDelay:.18}).action,'hold');});
test('ordinary escape from an edge lane cannot target the far lane in one command',()=>{const s=scene();s.player.x=-20;s.lane=0;s.coins=[coin(-20,80)];const d=planNative(s,{precision:false});assert.equal(d.action,'right');assert.equal(d.targetX,0);});
test('ordinary planning never selects the between-lane gaps used by continuous steering',()=>{const s=scene();s.coins=[coin(0,90),coin(0,120)];s.obstacles=[train(-20,90,90),train(20,90,90)];const d=planNative(s,{precision:false});assert.ok([-20,0,20].includes(d.targetX),JSON.stringify(d));assert.ok(Math.abs(d.targetX)<=20);});
test('oncoming trains beyond the static horizon still cause an early escape',()=>{const s=scene();s.obstacles=[{...train(0,500,59),velocityZ:0}];assert.equal(planNative(s,{precision:false}).action,'hold');s.obstacles[0].velocityZ=-150;const d=planNative(s,{precision:false});assert.ok(['left','right'].includes(d.action));assert.equal(d.risk,0);});
test('continuous collision times allow a diagonal escape without corner-box false positives',()=>{const s=scene();s.obstacles=[{...train(0,120,59),velocityZ:-100}];const d=planNative(s,{precision:false});assert.ok(['left','right'].includes(d.action));assert.equal(d.risk,0);});
test('stale moving-train observations are extrapolated before predicting danger',()=>{const s=scene();s.at=1400;s.obstacles=[{...train(0,120,59),velocityZ:-100,observedAt:1000}];assert.ok(planNative(s,{precision:false}).imminentRisk>0);});
test('lookahead preserves a timely future jump instead of pruning every airborne path',()=>{const s=scene();s.obstacles=[{x:0,y:3,z:140,hx:40,hy:3,hz:2}];for(const precision of [false,true]){const d=planNative(s,{precision});assert.equal(d.risk,0);assert.equal(d.imminentRisk,0);}});
test('continuous steering commits across the road early in the captured train/coin pattern',()=>{
  const s=scene();s.player={x:-8,y:.8,z:378.15};s.body={...s.body,x:-8,z:379.15};s.speed=112.8;s.verticalSpeed=-28;
  s.coins=[...[420,450,480,660,690].map(z=>coin(0,z)),...[495,645].map(z=>coin(10,z)),...[510,540,570,600,630].map(z=>coin(20,z))];
  s.obstacles=[train(-20,511,148),train(0,541,27.75)];
  const d=planNative(s,{precision:true});assert.equal(d.targetX,8);assert.equal(d.risk,0);assert.equal(d.imminentRisk,0);
});
test('reader rejects unknown player before reading native memory',()=>{globalThis.window={unityGame:{Module:{HEAPU8:new Uint8Array(4096),asm:{},wasmCodeUrl:'https://example.com/unknown.wasm'}}};try{assert.throws(()=>installLegacyReader(legacyProfile),/Unsupported game build/);}finally{delete globalThis.window;}});
test('profile binds exact source and deployed legacy player',()=>{assert.equal(legacyProfile.playerHash.length,64);assert.equal(legacyProfile.sourceHash,'7acb0ed25fa83d2542d73535381a93f3328d61fab037d10567bcab129c385142');assert.equal(legacyProfile.coordinateOffset,20);});

import {startNativePilot} from '../extension/native-pilot.js';
function pilotFixture(t, overrides={}) {
  t.mock.timers.enable({apis:['setInterval']});
  let clock=1000; t.mock.method(performance,'now',()=>clock);
  const calls={steer:0,act:0,pause:0,stop:0};
  const state={...scene(),runId:1,collected:0,samples:1,errors:0};
  Object.assign(state,overrides);
  globalThis.window={__noCoinPilotReader:{snapshot:()=>state,steer:()=>{calls.steer++;},act:()=>{calls.act++;return false;},pause:()=>{calls.pause++;},stop:()=>{calls.stop++;}}};
  globalThis.document={hidden:false,hasFocus:()=>true,getElementById:()=>null,createElement:()=>({style:{},textContent:''}),documentElement:{append:()=>{}},addEventListener:()=>{},removeEventListener:()=>{}};
  t.after(()=>{globalThis.window?.__noCoinPilotNative?.stop();delete globalThis.window;delete globalThis.document;});
  return {calls,state,tick:ms=>{clock+=ms;t.mock.timers.tick(ms);}};
}
test('native observation never moves or pauses even when coins were collected',t=>{const f=pilotFixture(t,{collected:4});startNativePilot({dry:true},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);assert.equal(f.calls.steer,0);assert.equal(f.calls.act,0);assert.equal(f.calls.pause,0);});
test('native pilot pauses and stops on an actual collected coin',t=>{const f=pilotFixture(t,{collected:1});startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);assert.equal(f.calls.pause,1);assert.equal(f.calls.steer,0);assert.match(window.__noCoinPilotNative.status().message,/Coin collected/);});
test('native watchdog stops after losing extension heartbeat',t=>{const f=pilotFixture(t);startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(3600);assert.equal(window.__noCoinPilotNative.status().running,false);assert.equal(f.calls.stop,1);});
test('auto-brake pauses on unresolved imminent collision',t=>{const f=pilotFixture(t,{obstacles:[{x:0,y:6,z:15,hx:8,hy:6,hz:2}]});startNativePilot({autoBrake:true},()=>({action:'hold',targetX:0,risk:1000000}));f.tick(25);assert.equal(f.calls.pause,1);assert.match(window.__noCoinPilotNative.status().message,/No safe predicted path/);});
test('ordinary hold does not repeatedly call the native action API',t=>{const f=pilotFixture(t);startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(250);assert.equal(f.calls.act,0);});
test('ordinary pilot never invokes direct steering even if a planner returns an off-lane target',t=>{const f=pilotFixture(t);let settings;startNativePilot({precision:false},(_,s)=>{settings=s;return {action:'hold',targetX:8,risk:0};});f.tick(250);assert.equal(settings.precision,false);assert.equal(f.calls.steer,0);assert.equal(f.calls.act,0);});
test('an old continuous-steering offset requires a fresh run instead of lingering between lanes',t=>{const f=pilotFixture(t,{player:{x:8,y:.8,z:0},lane:1,changing:false});startNativePilot({precision:false},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);assert.equal(f.calls.steer,0);assert.equal(f.calls.act,0);assert.equal(f.calls.pause,1);assert.match(window.__noCoinPilotNative.status().message,/fresh run/);});
test('ordinary mode lets an actual lane change settle before testing lane alignment',t=>{const f=pilotFixture(t,{player:{x:8,y:.8,z:0},lane:2,changing:true});startNativePilot({precision:false},()=>({action:'hold',targetX:20,risk:0}));f.tick(25);f.state.changing=false;f.tick(100);assert.equal(f.calls.pause,0);f.state.player.x=20;f.tick(700);assert.equal(f.calls.pause,0);assert.equal(f.calls.steer,0);});
test('future danger does not brake a currently executable safe maneuver',t=>{const f=pilotFixture(t,{obstacles:[{x:0,y:6,z:30,hx:8,hy:6,hz:2}]});startNativePilot({},()=>({action:'jump',targetX:0,risk:1000000,imminentRisk:0}));f.tick(25);assert.equal(f.calls.pause,0);assert.equal(f.calls.act,1);});
test('losing game focus pauses controlled play before stopping',t=>{const f=pilotFixture(t);document.hasFocus=()=>false;startNativePilot({},()=>({action:'left',targetX:-20,risk:0}));f.tick(25);assert.equal(f.calls.pause,1);assert.equal(f.calls.act,0);assert.equal(window.__noCoinPilotNative.status().running,false);assert.match(window.__noCoinPilotNative.status().message,/lost focus/);});
test('manual stop pauses controlled play',t=>{const f=pilotFixture(t);startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));window.__noCoinPilotNative.stop();assert.equal(f.calls.pause,1);assert.equal(f.calls.stop,1);});
test('sensor failure pauses controlled play before releasing the reader',t=>{const f=pilotFixture(t);window.__noCoinPilotReader.snapshot=()=>{throw new Error('Disconnected sensor');};startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);assert.equal(f.calls.pause,1);assert.equal(f.calls.stop,1);assert.match(window.__noCoinPilotNative.status().message,/Disconnected sensor/);});
test('a collected coin is reported even if the game has already paused',t=>{const f=pilotFixture(t,{running:false,paused:true,collected:1});startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);assert.equal(window.__noCoinPilotNative.status().running,false);assert.match(window.__noCoinPilotNative.status().message,/Coin collected/);});
test('auto-brake uses closing speed for an approaching train',t=>{const f=pilotFixture(t,{obstacles:[{x:0,y:15,z:45,hx:8.5,hy:14,hz:10,velocityZ:-150}]});startNativePilot({autoBrake:true},()=>({action:'hold',targetX:0,risk:1000000,imminentRisk:1000000,reason:'Approaching train'}));f.tick(25);assert.equal(f.calls.pause,1);assert.equal(window.__noCoinPilotNative.status().reason,'Approaching train');});
test('death ends the controller rather than pretending it is still active',t=>{const f=pilotFixture(t);startNativePilot({},()=>({action:'hold',targetX:0,risk:0}));f.tick(25);f.state.running=false;f.state.dead=true;f.tick(25);assert.equal(window.__noCoinPilotNative.status().running,false);assert.match(window.__noCoinPilotNative.status().message,/character died/);});

// Predictive risk alone should not abort an otherwise active attempt.
test('default pilot attempts the chosen move even with forecast risk',t=>{const f=pilotFixture(t,{coins:[coin(0,15)]});startNativePilot({},()=>({action:'left',targetX:-20,risk:100000,imminentRisk:100000}));f.tick(25);assert.equal(f.calls.pause,0);assert.equal(f.calls.act,1);assert.equal(window.__noCoinPilotNative.status().running,true);});
test('opt-in brake tries an accepted escape before considering a pause',t=>{const f=pilotFixture(t,{coins:[coin(0,15)]});window.__noCoinPilotReader.act=()=>{f.calls.act++;return true;};startNativePilot({autoBrake:true},()=>({action:'jump',targetX:0,risk:100000,imminentRisk:100000}));f.tick(25);assert.equal(f.calls.act,1);assert.equal(f.calls.pause,0);});
test('accepted lane target survives a stale native lane during movement',t=>{const f=pilotFixture(t);let settings;window.__noCoinPilotReader.act=()=>true;startNativePilot({},(_,s)=>{settings=s;return {action:s.pendingLane===null?'right':'hold',targetX:20,risk:0};});f.tick(25);f.state.changing=true;f.tick(125);assert.equal(settings.pendingLane,2);assert.equal(f.calls.pause,0);f.state.changing=false;f.state.lane=2;f.state.player.x=20;f.tick(125);assert.equal(settings.pendingLane,null);});
test('ordinary prediction follows a pending lane instead of returning to the old lane',()=>{const s=scene();s.changing=true;const d=planNative(s,{precision:false,pendingLane:2});assert.equal(d.action,'hold');assert.equal(d.targetX,20);});

test('low frame-rate gravity cannot claim the same jump clearance as 60 FPS',()=>{const s=scene();s.obstacles=[{x:0,y:7,z:55,hx:40,hy:7,hz:2}];const fast=planNative({...s,engineStep:1/60},{precision:false}),slow=planNative({...s,engineStep:1/3},{precision:false});assert.equal(fast.action,'jump');assert.equal(fast.risk,0);assert.ok(slow.risk>0);assert.ok(slow.collisionIn<1);});
